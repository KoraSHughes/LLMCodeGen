# Tools Setup

Guides showing how to set up the tools used in OpenTitan's development:

- [FPGA Setup](./setup_fpga.md)
- [Verilator Setup](./setup_verilator.md)
- [Installing Vivado](./install_vivado/README.md)
