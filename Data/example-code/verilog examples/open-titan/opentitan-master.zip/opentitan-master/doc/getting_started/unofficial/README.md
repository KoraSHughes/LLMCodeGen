# Unofficial Guides

In the interest of reducing maintanance burden, OpenTitan only offically supports a specific set of use cases and being developed on a specific platform with specific tool versions.
However, contributors develop OpenTitan on a range of different setups and may play with alternative use cases.
These guides are written by contributors to help with alternative setups and use cases that are not officially supported by the project.
