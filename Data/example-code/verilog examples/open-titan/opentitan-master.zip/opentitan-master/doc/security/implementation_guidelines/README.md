# Implementation Guidelines

## [Secure Hardware Design Guidelines](./hardware/README.md)

## [Reset vs. Non-Reset Flops](./reset_vs_non-reset_flops/README.md)
