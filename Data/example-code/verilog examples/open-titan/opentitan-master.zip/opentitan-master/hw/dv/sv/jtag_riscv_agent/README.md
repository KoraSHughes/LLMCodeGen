# JTAG RISCV DV UVM Agent

JTAG RISCV UVM Agent is extended from DV library agent classes.
This is a high-level agent that builds on top of the JTAG agent.
