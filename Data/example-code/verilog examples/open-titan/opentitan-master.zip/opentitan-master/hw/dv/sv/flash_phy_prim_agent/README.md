# Flash Phy Primitive UVM Agent

FLASH_PHY_PRIM UVM Agent is extended from DV library agent classes.
