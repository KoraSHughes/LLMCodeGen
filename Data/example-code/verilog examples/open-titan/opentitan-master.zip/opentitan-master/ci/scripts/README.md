# CI scripts

These scripts are run as part of CI. The top-level orchestration is
contained in azure-pipelines.yml.
